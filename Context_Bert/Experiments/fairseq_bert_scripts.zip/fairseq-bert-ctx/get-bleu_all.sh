
srclng=de
tgtlng=en
hid=512

for file in tmp/iwslt_de-en_H512_tok6000_each-bsz3000keyword_train_sent/test/*.log;
do
	tag=$( tail -n 1 $file )
    echo "$tag $file" >> bleu-1prevkeyword-train-sent.txt
done;