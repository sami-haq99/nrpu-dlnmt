#!/usr/bin/env bash
# Paras: lng, startofdoc
# Execute this script in $prep, e.g. iwslt14.tokenized.de-en

lng=$1
path=/home/buraq/sami/nmt_toolkits/fair-bert-nmt/data/iwslt14.tok.de-en
moses=/home/buraq/sami/nmt_toolkits/fair-bert-nmt/data
outpath=$path/bert
startofdoc=${2:-"startofdocumentplaceholder"}

echo "src lng $lng"

for sub  in train valid test
do
    inp=$path/tmp/${sub}.${lng}.with_startofdoc
    oup=$outpath/${sub}.bert.${lng}
    sent=$outpath/${sub}.bert.sent.${lng}
    echo "$inp  ==>  $oup  ==>  $sent"
    # sed -r 's/(@@ )|(@@ ?$)//g' ${sub}.${lng} > ${sub}.bert.${lng}.tok
    $moses/mosesdecoder/scripts/tokenizer/detokenizer.perl -l $lng < $inp > $oup
    # rm ${sub}.bert.${lng}.tok
    cat $oup | grep -v ^$startofdoc > $sent
done
