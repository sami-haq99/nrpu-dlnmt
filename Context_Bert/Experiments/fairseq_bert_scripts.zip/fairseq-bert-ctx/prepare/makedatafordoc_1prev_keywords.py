import io
import os
import argparse
import yake

#yake pramters
max_ngram_size = 2
deduplication_thresold = 0.9
deduplication_algo = 'seqm'
windowSize = 1
numOfKeywords = 10


parser = argparse.ArgumentParser()
parser.add_argument('--lng', type=str, default='en')
parser.add_argument('--startofdoc', default="startofdocumentplaceholder")
parser.add_argument('--ctx-size', default=1, type=int)
args = parser.parse_args()

lng = args.lng
language = lng
#initialize keyword extractor
kw_extractor = yake.KeywordExtractor(lan=language, n=max_ngram_size, dedupLim=deduplication_thresold, dedupFunc=deduplication_algo, windowsSize=windowSize, top=numOfKeywords, features=None)


path = '/home/buraq/sami/nmt_toolkits/fair-bert-nmt/data/iwslt14.tok.de-en/bert/1prevkeyword_bi'
print('lng {}'.format(lng))
subsets = ['train','valid', 'test']
for subset in subsets:
    fn = path+'/'+'{}.bert.{}'.format(subset, lng)
    assert os.path.exists(fn)

print("Using start of doc: %s" % args.startofdoc)
size_str = "" if args.ctx_size == 1 else "{:d}".format(args.ctx_size)
for subset in subsets:
    fn = path+'/'+'{}.bert.{}'.format(subset, lng)
    tgtfn = path+'/'+'{}{}.bert.doc.{}'.format(subset, size_str, lng)
    print("%s  ==>  %s" % (fn, tgtfn))
    prevs = []
    with io.open(fn, 'r', encoding='utf8', newline='\n') as src:
        with io.open(tgtfn, 'w', encoding='utf8', newline='\n') as tgt:
            for line in src:
                line = line.strip()
                if line:
                    if line == args.startofdoc:
                        prevs = []
                    else:
                        newline = '[CLS] {} [SEP] {} [SEP]'.format(' '.join(prevs), line)
                        #keyword extraction
                        keywords = kw_extractor.extract_keywords(line)
                        str_keywords = ''
                        for kw in keywords:
                            str_keywords = str_keywords+' '+kw[0]

                        prevs = prevs[max(len(prevs) - args.ctx_size + 1, 0):] + [str_keywords, ]
                        tgt.write(newline + '\n')
    bpein = path+'/'+"{}.{}".format(subset, lng)
    docin =  path+'/'+"{}{}.{}.doc.in".format(subset, size_str, lng)
    print("Paste: %s + %s  ==>  %s" % (bpein, tgtfn, docin))
    paste_cmd = "paste -d \"\n\" {} {} > {}".format(bpein, tgtfn, docin)
    print("cmd: %s" % paste_cmd)
    os.system(paste_cmd)
